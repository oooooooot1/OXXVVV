"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertCircle, User, Users, ShieldAlert } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

// Mock database for authentication
// In a real app, this would be a server-side API call
const mockUsers = {
  students: [
    {
      fullName: "Ahmed Mohammed",
      gender: "male",
      universityID: "ST12345",
      group: "A",
      contactNumber: "0501234567",
      secretCode: "1234@ABCD",
    },
    {
      fullName: "Fatima Ali",
      gender: "female",
      universityID: "ST67890",
      group: "B",
      contactNumber: "0507654321",
      secretCode: "5678@EFGH",
    },
  ],
  faculty: [
    {
      fullName: "Dr. Omar Hassan",
      gender: "male",
      subject: "Computer Science",
      contactNumber: "0551234567",
      secretCode: "4321@DCBA",
    },
    {
      fullName: "Dr. Aisha Mahmoud",
      gender: "female",
      subject: "Mathematics",
      contactNumber: "0559876543",
      secretCode: "8765@HGFE",
    },
  ],
  adminCode: "LVERRRR@@0424",
}

export function LoginForm() {
  const router = useRouter()
  const { login, failedAttempts, setFailedAttempts, isBlocked, blockUntil } = useAuth()
  const [activeTab, setActiveTab] = useState("student")
  const [error, setError] = useState("")

  // Student form state
  const [studentName, setStudentName] = useState("")
  const [studentGender, setStudentGender] = useState<"male" | "female">("male")
  const [studentId, setStudentId] = useState("")
  const [studentContact, setStudentContact] = useState("")
  const [studentCode, setStudentCode] = useState("")

  // Faculty form state
  const [facultyName, setFacultyName] = useState("")
  const [facultyGender, setFacultyGender] = useState<"male" | "female">("male")
  const [facultySubject, setFacultySubject] = useState("")
  const [facultyContact, setFacultyContact] = useState("")
  const [facultyCode, setFacultyCode] = useState("")

  // Admin form state
  const [adminCode, setAdminCode] = useState("")

  // Check if user is blocked
  useEffect(() => {
    if (failedAttempts >= 3) {
      const blockTime = new Date()
      blockTime.setMinutes(blockTime.getMinutes() + 10)
      localStorage.setItem("mw_block_until", blockTime.toString())
    }
  }, [failedAttempts])

  const handleStudentLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (isBlocked) {
      setError("Too many failed attempts. Please try again later.")
      return
    }

    const student = mockUsers.students.find((s) => s.fullName === studentName && s.secretCode === studentCode)

    if (student) {
      login({
        role: "student",
        fullName: studentName,
        gender: studentGender,
        universityID: studentId,
        group: student.group,
        contactNumber: studentContact,
        secretCode: studentCode,
      })
      router.push("/dashboard")
    } else {
      setError("Invalid credentials. Please try again.")
      setFailedAttempts(failedAttempts + 1)
    }
  }

  const handleFacultyLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (isBlocked) {
      setError("Too many failed attempts. Please try again later.")
      return
    }

    const faculty = mockUsers.faculty.find((f) => f.fullName === facultyName && f.secretCode === facultyCode)

    if (faculty) {
      login({
        role: "faculty",
        fullName: facultyName,
        gender: facultyGender,
        subject: facultySubject,
        contactNumber: facultyContact,
        secretCode: facultyCode,
      })
      router.push("/dashboard")
    } else {
      setError("Invalid credentials. Please try again.")
      setFailedAttempts(failedAttempts + 1)
    }
  }

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault()

    if (isBlocked) {
      setError("Too many failed attempts. Please try again later.")
      return
    }

    if (adminCode === mockUsers.adminCode) {
      login({
        role: "admin",
        adminCode: adminCode,
      })
      router.push("/dashboard")
    } else {
      setError("Invalid admin code. Please try again.")
      setFailedAttempts(failedAttempts + 1)
    }
  }

  return (
    <Card className="w-full shadow-lg border-slate-200 dark:border-slate-700">
      <CardHeader>
        <CardTitle className="text-center">Sign In</CardTitle>
        <CardDescription className="text-center">Select your role to continue</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {isBlocked && blockUntil && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Account Temporarily Blocked</AlertTitle>
            <AlertDescription>
              Too many failed attempts. Please try again after {new Date(blockUntil).toLocaleTimeString()}.
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="student" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="student" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Student
            </TabsTrigger>
            <TabsTrigger value="faculty" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Faculty
            </TabsTrigger>
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <ShieldAlert className="h-4 w-4" />
              Admin
            </TabsTrigger>
          </TabsList>

          <TabsContent value="student">
            <form onSubmit={handleStudentLogin} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="student-name">Full Name</Label>
                <Input
                  id="student-name"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Gender</Label>
                <RadioGroup
                  value={studentGender}
                  onValueChange={(value) => setStudentGender(value as "male" | "female")}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="male" id="student-male" />
                    <Label htmlFor="student-male">Male</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="female" id="student-female" />
                    <Label htmlFor="student-female">Female</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="student-id">University ID</Label>
                <Input id="student-id" value={studentId} onChange={(e) => setStudentId(e.target.value)} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="student-contact">Contact Number</Label>
                <Input
                  id="student-contact"
                  value={studentContact}
                  onChange={(e) => setStudentContact(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="student-code">Secret Code (Format: 1234@ABCD)</Label>
                <Input
                  id="student-code"
                  value={studentCode}
                  onChange={(e) => setStudentCode(e.target.value)}
                  placeholder="1234@ABCD"
                  required
                />
              </div>

              <Button type="submit" className="w-full">
                Sign In
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="faculty">
            <form onSubmit={handleFacultyLogin} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="faculty-name">Full Name</Label>
                <Input
                  id="faculty-name"
                  value={facultyName}
                  onChange={(e) => setFacultyName(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Gender</Label>
                <RadioGroup
                  value={facultyGender}
                  onValueChange={(value) => setFacultyGender(value as "male" | "female")}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="male" id="faculty-male" />
                    <Label htmlFor="faculty-male">Male</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="female" id="faculty-female" />
                    <Label htmlFor="faculty-female">Female</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label htmlFor="faculty-subject">Subject</Label>
                <Input
                  id="faculty-subject"
                  value={facultySubject}
                  onChange={(e) => setFacultySubject(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="faculty-contact">Contact Number</Label>
                <Input
                  id="faculty-contact"
                  value={facultyContact}
                  onChange={(e) => setFacultyContact(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="faculty-code">Secret Code (Format: 4321@DCBA)</Label>
                <Input
                  id="faculty-code"
                  value={facultyCode}
                  onChange={(e) => setFacultyCode(e.target.value)}
                  placeholder="4321@DCBA"
                  required
                />
              </div>

              <Button type="submit" className="w-full">
                Sign In
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="admin">
            <form onSubmit={handleAdminLogin} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="admin-code">Admin Code</Label>
                <Input
                  id="admin-code"
                  type="password"
                  value={adminCode}
                  onChange={(e) => setAdminCode(e.target.value)}
                  required
                />
              </div>

              <Button type="submit" className="w-full">
                Sign In
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-center">
        <p className="text-xs text-muted-foreground">University MW Global - Educational Platform © Osama Bashir</p>
      </CardFooter>
    </Card>
  )
}

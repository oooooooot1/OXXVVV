"use client"

import { useState } from "react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, ImageIcon, LinkIcon, FileArchiveIcon as FileZip, File } from "lucide-react"

// Mock library resources
const resources = [
  {
    id: 1,
    title: "Introduction to Computer Science",
    description: "Comprehensive guide to CS fundamentals",
    type: "pdf",
    date: "2023-08-01",
    size: "2.4 MB",
  },
  {
    id: 2,
    title: "Calculus Formulas",
    description: "Quick reference for calculus formulas",
    type: "pdf",
    date: "2023-07-15",
    size: "1.1 MB",
  },
  {
    id: 3,
    title: "Physics Lab Resources",
    description: "Collection of physics lab materials",
    type: "zip",
    date: "2023-07-10",
    size: "15.7 MB",
  },
  {
    id: 4,
    title: "Campus Map",
    description: "Detailed map of the university campus",
    type: "image",
    date: "2023-06-20",
    size: "3.5 MB",
  },
  {
    id: 5,
    title: "Academic Calendar",
    description: "Important dates for the academic year",
    type: "text",
    date: "2023-06-15",
    size: "12 KB",
  },
  {
    id: 6,
    title: "Online Learning Portal",
    description: "Link to the university's e-learning platform",
    type: "link",
    date: "2023-06-01",
    url: "https://elearning.example.edu",
  },
]

export function LibraryResources() {
  const [activeTab, setActiveTab] = useState("all")

  const getFilteredResources = () => {
    if (activeTab === "all") return resources
    return resources.filter((resource) => resource.type === activeTab)
  }

  const getResourceIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FileText className="h-4 w-4" />
      case "image":
        return <ImageIcon className="h-4 w-4" />
      case "link":
        return <LinkIcon className="h-4 w-4" />
      case "zip":
        return <FileZip className="h-4 w-4" />
      default:
        return <File className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-6 w-full">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="pdf">PDF</TabsTrigger>
          <TabsTrigger value="image">Images</TabsTrigger>
          <TabsTrigger value="text">Text</TabsTrigger>
          <TabsTrigger value="zip">ZIP</TabsTrigger>
          <TabsTrigger value="link">Links</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-4">
          <ScrollArea className="h-[200px] pr-4">
            <div className="space-y-4">
              {getFilteredResources().map((resource) => (
                <div key={resource.id} className="flex items-start gap-3">
                  <div className="mt-0.5 bg-primary/10 p-2 rounded-md">{getResourceIcon(resource.type)}</div>
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <h4 className="font-medium">{resource.title}</h4>
                      <span className="text-xs text-muted-foreground">{resource.date}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{resource.description}</p>
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-xs text-muted-foreground">{resource.size}</span>
                      <Button variant="ghost" size="sm" className="h-7">
                        {resource.type === "link" ? "Visit" : "Download"}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>

      <Button variant="outline" size="sm" className="w-full">
        Browse All Resources
      </Button>
    </div>
  )
}

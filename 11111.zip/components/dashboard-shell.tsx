"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/components/auth-provider"
import { Button } from "@/components/ui/button"
import { WelcomeModal } from "@/components/welcome-modal"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"
import {
  Home,
  FileText,
  Users,
  Calendar,
  Map,
  Phone,
  Code,
  Menu,
  Settings,
  PanelLeft,
  Clock,
  Edit,
  Plus,
  Palette,
} from "lucide-react"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const { user, isAuthenticated, showWelcome, setShowWelcome } = useAuth()
  const [isMounted, setIsMounted] = useState(false)
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  useEffect(() => {
    if (isMounted && !isAuthenticated) {
      router.push("/")
    }
  }, [isMounted, isAuthenticated, router])

  const handleAdminAction = (path: string) => {
    setIsAdminPanelOpen(false)
    router.push(path)
  }

  if (!isMounted || !isAuthenticated) {
    return null
  }

  return (
    <>
      {showWelcome && user && "fullName" in user && (
        <WelcomeModal fullName={user.fullName} onClose={() => setShowWelcome(false)} />
      )}

      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-40 border-b bg-background">
          <div className="container flex h-16 items-center justify-between py-4">
            <div className="flex items-center gap-4">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle Menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[240px] sm:w-[300px]">
                  <SheetHeader className="pb-6">
                    <SheetTitle>University MW Global</SheetTitle>
                  </SheetHeader>
                  <nav className="flex flex-col gap-2">
                    <Link
                      href="/dashboard"
                      className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
                    >
                      <Home className="h-4 w-4" />
                      Home
                    </Link>
                    <Link
                      href="/dashboard/files"
                      className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
                    >
                      <FileText className="h-4 w-4" />
                      Files
                    </Link>
                    <Link
                      href="/dashboard/people"
                      className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
                    >
                      <Users className="h-4 w-4" />
                      People Directory
                    </Link>
                    <Link
                      href="/dashboard/schedule"
                      className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
                    >
                      <Calendar className="h-4 w-4" />
                      Schedule
                    </Link>
                    <Link
                      href="/dashboard/map"
                      className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
                    >
                      <Map className="h-4 w-4" />
                      Campus Map
                    </Link>
                    <Link
                      href="/dashboard/contact"
                      className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
                    >
                      <Phone className="h-4 w-4" />
                      Contact Us
                    </Link>
                    <Link
                      href="/dashboard/developer"
                      className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
                    >
                      <Code className="h-4 w-4" />
                      MW Developer
                    </Link>
                  </nav>
                </SheetContent>
              </Sheet>
              <Link href="/dashboard" className="flex items-center gap-2">
                <span className="font-bold text-xl hidden md:inline-block">University MW Global</span>
                <span className="font-bold text-xl md:hidden">UMW</span>
              </Link>
            </div>
            <MainNav />
            <UserNav />
          </div>
        </header>
        <div className="flex flex-1">
          <aside className="hidden w-[240px] flex-col border-r bg-muted/40 md:flex">
            <nav className="flex flex-col gap-2 p-4">
              <Link
                href="/dashboard"
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
              >
                <Home className="h-4 w-4" />
                Home
              </Link>
              <Link
                href="/dashboard/files"
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
              >
                <FileText className="h-4 w-4" />
                Files
              </Link>
              <Link
                href="/dashboard/people"
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
              >
                <Users className="h-4 w-4" />
                People Directory
              </Link>
              <Link
                href="/dashboard/schedule"
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
              >
                <Calendar className="h-4 w-4" />
                Schedule
              </Link>
              <Link
                href="/dashboard/map"
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
              >
                <Map className="h-4 w-4" />
                Campus Map
              </Link>
              <Link
                href="/dashboard/contact"
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
              >
                <Phone className="h-4 w-4" />
                Contact Us
              </Link>
              <Link
                href="/dashboard/developer"
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium hover:bg-accent"
              >
                <Code className="h-4 w-4" />
                MW Developer
              </Link>
            </nav>
          </aside>
          <main className="flex-1 overflow-auto relative">
            {user && user.role === "admin" && (
              <div className="fixed bottom-6 right-6 z-50">
                <Dialog open={isAdminPanelOpen} onOpenChange={setIsAdminPanelOpen}>
                  <Button
                    className="rounded-full h-14 w-14 shadow-lg"
                    size="icon"
                    onClick={() => setIsAdminPanelOpen(true)}
                  >
                    <Settings className="h-6 w-6" />
                  </Button>
                  <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                      <DialogTitle className="text-right text-xl">لوحة تحكم المسؤول</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 mt-4">
                      <div>
                        <h5 className="font-medium mb-2 text-right">إدارة الجدول</h5>
                        <div className="grid grid-cols-2 gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="justify-start"
                            onClick={() => handleAdminAction("/dashboard/schedule?edit=lectures")}
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            تعديل المحاضرات
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="justify-start"
                            onClick={() => handleAdminAction("/dashboard/schedule?edit=times")}
                          >
                            <Clock className="h-4 w-4 mr-2" />
                            تعديل الأوقات
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="justify-start"
                            onClick={() => handleAdminAction("/dashboard/schedule?action=add-lecture")}
                          >
                            <Plus className="h-4 w-4 mr-2" />
                            إضافة محاضرة
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="justify-start"
                            onClick={() => handleAdminAction("/dashboard/schedule?action=add-group")}
                          >
                            <PanelLeft className="h-4 w-4 mr-2" />
                            إضافة مجموعة
                          </Button>
                        </div>
                      </div>
                      <Separator />
                      <div>
                        <h5 className="font-medium mb-2 text-right">إعدادات العرض</h5>
                        <div className="grid grid-cols-2 gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="justify-start"
                            onClick={() => handleAdminAction("/dashboard/settings?tab=colors")}
                          >
                            <Palette className="h-4 w-4 mr-2" />
                            ألوان المواد
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="justify-start"
                            onClick={() => handleAdminAction("/dashboard/schedule?edit=countdown")}
                          >
                            <Calendar className="h-4 w-4 mr-2" />
                            العد التنازلي
                          </Button>
                        </div>
                      </div>
                      <Separator />
                      <div>
                        <h5 className="font-medium mb-2 text-right">الملاحظات والإعلانات</h5>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full justify-start"
                          onClick={() => handleAdminAction("/dashboard/schedule?tab=notes")}
                        >
                          <FileText className="h-4 w-4 mr-2" />
                          إدارة الملاحظات
                        </Button>
                        <p className="text-xs text-muted-foreground mt-2 text-right">
                          الملاحظات التي تضيفها ستظهر لجميع الطلاب والمعلمين
                        </p>
                      </div>
                      <div className="pt-2">
                        <Badge variant="outline" className="w-full justify-center">
                          وضع المسؤول نشط
                        </Badge>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            )}
            <div className="container py-6">{children}</div>
          </main>
        </div>
      </div>
    </>
  )
}

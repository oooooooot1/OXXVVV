"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"

// Mock class leaders data
const classLeaders = [
  {
    id: 1,
    name: "Mohammed Al-Farsi",
    group: "A",
    department: "Computer Science",
    year: 3,
    isLeader: true,
  },
  {
    id: 2,
    name: "Fatima Al-Zahra",
    group: "B",
    department: "Medicine",
    year: 2,
    isLeader: false,
  },
  {
    id: 3,
    name: "Ahmed Ibrahim",
    group: "A",
    department: "Engineering",
    year: 4,
    isLeader: true,
  },
  {
    id: 4,
    name: "Layla Mahmoud",
    group: "B",
    department: "Business",
    year: 3,
    isLeader: false,
  },
  {
    id: 5,
    name: "Omar Hassan",
    group: "A",
    department: "Law",
    year: 2,
    isLeader: false,
  },
]

export function ClassLeaders() {
  // استخدام نفس بيانات الطلاب من صفحة الأشخاص
  // في تطبيق حقيقي، ستقوم بجلب هذه البيانات من API أو مخزن حالة عام
  const leaders = classLeaders.filter((student) => student.isLeader)

  return (
    <ScrollArea className="h-[300px] pr-4">
      <div className="space-y-4">
        {leaders.length > 0 ? (
          leaders.map((leader) => (
            <div key={leader.id} className="flex items-center gap-4">
              <div className="relative">
                <Avatar>
                  <AvatarFallback>
                    {leader.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <span className="absolute -top-1 -right-1 flex h-4 w-4 animate-pulse">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-primary items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                      className="w-3 h-3 text-white"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </span>
                </span>
              </div>
              <div>
                <p className="font-medium">{leader.name}</p>
                <p className="text-sm text-muted-foreground">
                  المجموعة {leader.group} • {leader.department} • السنة {leader.year}
                </p>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground">لم يتم تعيين قادة فصل بعد.</p>
          </div>
        )}
      </div>
    </ScrollArea>
  )
}

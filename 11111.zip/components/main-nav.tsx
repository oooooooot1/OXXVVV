"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export function MainNav() {
  const pathname = usePathname()

  return (
    <nav className="hidden md:flex items-center gap-6 text-sm">
      <Link
        href="/dashboard"
        className={cn(
          "transition-colors hover:text-foreground/80",
          pathname === "/dashboard" ? "text-foreground font-medium" : "text-foreground/60",
        )}
      >
        Home
      </Link>
      <Link
        href="/dashboard/files"
        className={cn(
          "transition-colors hover:text-foreground/80",
          pathname?.startsWith("/dashboard/files") ? "text-foreground font-medium" : "text-foreground/60",
        )}
      >
        Files
      </Link>
      <Link
        href="/dashboard/people"
        className={cn(
          "transition-colors hover:text-foreground/80",
          pathname?.startsWith("/dashboard/people") ? "text-foreground font-medium" : "text-foreground/60",
        )}
      >
        People
      </Link>
      <Link
        href="/dashboard/schedule"
        className={cn(
          "transition-colors hover:text-foreground/80",
          pathname?.startsWith("/dashboard/schedule") ? "text-foreground font-medium" : "text-foreground/60",
        )}
      >
        Schedule
      </Link>
    </nav>
  )
}

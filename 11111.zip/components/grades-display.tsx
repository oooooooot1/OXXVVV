"use client"

import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"

// Mock grades data
const grades = [
  {
    course: "Computer Science 101",
    grade: 92,
    gpa: 4.0,
    attended: 15,
    missed: 1,
  },
  {
    course: "Mathematics 202",
    grade: 88,
    gpa: 3.7,
    attended: 14,
    missed: 2,
  },
  {
    course: "Physics 101",
    grade: 85,
    gpa: 3.5,
    attended: 13,
    missed: 3,
  },
  {
    course: "English Literature",
    grade: 90,
    gpa: 4.0,
    attended: 16,
    missed: 0,
  },
  {
    course: "History 101",
    grade: 82,
    gpa: 3.3,
    attended: 12,
    missed: 4,
  },
]

export function GradesDisplay() {
  const calculateOverallGPA = () => {
    const totalGPA = grades.reduce((sum, course) => sum + course.gpa, 0)
    return (totalGPA / grades.length).toFixed(2)
  }

  const calculateAttendanceRate = () => {
    const totalAttended = grades.reduce((sum, course) => sum + course.attended, 0)
    const totalClasses = grades.reduce((sum, course) => sum + course.attended + course.missed, 0)
    return ((totalAttended / totalClasses) * 100).toFixed(1)
  }

  const getStarRating = () => {
    const gpa = Number.parseFloat(calculateOverallGPA())
    return Math.round(gpa)
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col items-center justify-center py-2">
        <div className="flex items-center mb-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <svg
              key={star}
              className={`w-6 h-6 ${star <= getStarRating() ? "text-yellow-400" : "text-gray-300"}`}
              fill="currentColor"
              viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
            </svg>
          ))}
        </div>
        <div className="text-center">
          <p className="text-sm font-medium">Overall GPA: {calculateOverallGPA()}</p>
          <p className="text-sm text-muted-foreground">Attendance Rate: {calculateAttendanceRate()}%</p>
        </div>
      </div>

      <Separator />

      <ScrollArea className="h-[200px] pr-4">
        <div className="space-y-4">
          {grades.map((course, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between items-center">
                <h4 className="font-medium">{course.course}</h4>
                <span className="font-bold">{course.grade}%</span>
              </div>
              <Progress value={course.grade} className="h-2" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>GPA: {course.gpa.toFixed(1)}</span>
                <span>
                  Attended: {course.attended}/{course.attended + course.missed} classes
                </span>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <div className="pt-2 text-center italic text-sm text-muted-foreground">
        "One does not achieve without effort."
      </div>
    </div>
  )
}

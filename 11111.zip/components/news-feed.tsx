"use client"

import { useState, useEffect } from "react"
import { formatDistanceToNow } from "date-fns"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Mock news data
const mockNews = [
  {
    id: 1,
    title: "Fall Semester Registration Open",
    content: "Registration for the Fall semester is now open. Please register before August 15th.",
    date: new Date(2023, 7, 1),
    author: "Academic Affairs",
    type: "announcement",
  },
  {
    id: 2,
    title: "New Library Hours",
    content: "The university library will now be open from 8 AM to 10 PM on weekdays and 10 AM to 6 PM on weekends.",
    date: new Date(2023, 7, 5),
    author: "Library Administration",
    type: "update",
  },
  {
    id: 3,
    title: "Campus Maintenance Notice",
    content: "The main campus will undergo maintenance on August 10th. Some facilities may be temporarily unavailable.",
    date: new Date(2023, 7, 8),
    author: "Facilities Management",
    type: "notice",
  },
  {
    id: 4,
    title: "Scholarship Applications",
    content: "Applications for the annual merit scholarship are now being accepted. Deadline is September 1st.",
    date: new Date(2023, 7, 12),
    author: "Financial Aid Office",
    type: "opportunity",
  },
  {
    id: 5,
    title: "Guest Lecture Series",
    content:
      "A series of guest lectures by industry experts will be held throughout September. Check the events calendar for details.",
    date: new Date(2023, 7, 15),
    author: "Events Committee",
    type: "event",
  },
]

export function NewsFeed() {
  const [news, setNews] = useState(mockNews)
  const [selectedNews, setSelectedNews] = useState<(typeof mockNews)[0] | null>(null)

  // Auto-refresh every 10 minutes
  useEffect(() => {
    const interval = setInterval(
      () => {
        // In a real app, this would fetch fresh news from an API
        setNews([...mockNews])
      },
      10 * 60 * 1000,
    )

    return () => clearInterval(interval)
  }, [])

  const getBadgeVariant = (type: string) => {
    switch (type) {
      case "announcement":
        return "default"
      case "update":
        return "outline"
      case "notice":
        return "secondary"
      case "opportunity":
        return "destructive"
      case "event":
        return "default"
      default:
        return "outline"
    }
  }

  return (
    <div className="space-y-4">
      <ScrollArea className="h-[300px] pr-4">
        {news.map((item) => (
          <div key={item.id} className="mb-4">
            <div className="flex justify-between items-start">
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="link"
                    className="p-0 h-auto font-semibold text-left justify-start"
                    onClick={() => setSelectedNews(item)}
                  >
                    {item.title}
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>{selectedNews?.title}</DialogTitle>
                    <DialogDescription>
                      Posted by {selectedNews?.author} • {selectedNews?.date.toLocaleDateString()}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p>{selectedNews?.content}</p>
                    <div className="flex justify-end">
                      <Badge variant={getBadgeVariant(selectedNews?.type || "")}>{selectedNews?.type}</Badge>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <Badge variant={getBadgeVariant(item.type)}>{item.type}</Badge>
            </div>
            <p className="text-sm text-muted-foreground mt-1">{formatDistanceToNow(item.date, { addSuffix: true })}</p>
            <Separator className="mt-2" />
          </div>
        ))}
      </ScrollArea>
      <Button variant="outline" size="sm" className="w-full">
        View All News
      </Button>
    </div>
  )
}

"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"

type UserRole = "student" | "faculty" | "admin" | null
type Gender = "male" | "female"
type Group = "A" | "B"

interface StudentUser {
  role: "student"
  fullName: string
  gender: Gender
  universityID: string
  group: Group
  contactNumber: string
  secretCode: string
}

interface FacultyUser {
  role: "faculty"
  fullName: string
  gender: Gender
  subject: string
  contactNumber: string
  secretCode: string
}

interface AdminUser {
  role: "admin"
  adminCode: string
}

type User = StudentUser | FacultyUser | AdminUser | null

interface AuthContextType {
  user: User
  role: UserRole
  login: (userData: User) => void
  logout: () => void
  isAuthenticated: boolean
  showWelcome: boolean
  setShowWelcome: (show: boolean) => void
  failedAttempts: number
  setFailedAttempts: (attempts: number) => void
  isBlocked: boolean
  blockUntil: Date | null
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(null)
  const [role, setRole] = useState<UserRole>(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [showWelcome, setShowWelcome] = useState(false)
  const [failedAttempts, setFailedAttempts] = useState(0)
  const [isBlocked, setIsBlocked] = useState(false)
  const [blockUntil, setBlockUntil] = useState<Date | null>(null)

  // Check for stored auth on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("mw_user")
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser)
      setUser(parsedUser)
      setRole(parsedUser.role)
      setIsAuthenticated(true)
    }
  }, [])

  // Check if block period has expired
  useEffect(() => {
    if (blockUntil && new Date() > blockUntil) {
      setIsBlocked(false)
      setBlockUntil(null)
      setFailedAttempts(0)
    }
  }, [blockUntil])

  const login = (userData: User) => {
    setUser(userData)
    setRole(userData?.role || null)
    setIsAuthenticated(true)
    setShowWelcome(true)
    localStorage.setItem("mw_user", JSON.stringify(userData))
  }

  const logout = () => {
    setUser(null)
    setRole(null)
    setIsAuthenticated(false)
    localStorage.removeItem("mw_user")
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        login,
        logout,
        isAuthenticated,
        showWelcome,
        setShowWelcome,
        failedAttempts,
        setFailedAttempts,
        isBlocked,
        blockUntil,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

// Mock events data
const events = [
  {
    id: 1,
    name: "Summer Break",
    date: new Date(2023, 11, 15), // December 15, 2023
    type: "holiday",
  },
  {
    id: 2,
    name: "Graduation Ceremony",
    date: new Date(2023, 9, 30), // October 30, 2023
    type: "ceremony",
  },
  {
    id: 3,
    name: "Midterm Exams",
    date: new Date(2023, 8, 20), // September 20, 2023
    type: "exam",
  },
]

interface TimeLeft {
  days: number
  hours: number
  minutes: number
  seconds: number
  total: number
}

export function CountdownWidget() {
  const [timeLeft, setTimeLeft] = useState<Record<number, TimeLeft>>({})

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime()

      const newTimeLeft: Record<number, TimeLeft> = {}

      events.forEach((event) => {
        const difference = event.date.getTime() - now

        if (difference > 0) {
          newTimeLeft[event.id] = {
            days: Math.floor(difference / (1000 * 60 * 60 * 24)),
            hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
            minutes: Math.floor((difference / 1000 / 60) % 60),
            seconds: Math.floor((difference / 1000) % 60),
            total: difference,
          }
        }
      })

      setTimeLeft(newTimeLeft)
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)

    return () => clearInterval(timer)
  }, [])

  const getProgressValue = (eventId: number) => {
    const event = events.find((e) => e.id === eventId)
    if (!event || !timeLeft[eventId]) return 0

    const now = new Date().getTime()
    const eventDate = event.date.getTime()
    const oneMonthInMs = 30 * 24 * 60 * 60 * 1000

    const startDate = eventDate - oneMonthInMs
    const totalDuration = eventDate - startDate
    const elapsed = now - startDate

    return Math.min(100, Math.max(0, (elapsed / totalDuration) * 100))
  }

  return (
    <div className="space-y-4">
      {events.map((event) => (
        <Card key={event.id} className="overflow-hidden">
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-medium">{event.name}</h3>
              <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">{event.type}</span>
            </div>

            {timeLeft[event.id] ? (
              <>
                <div className="grid grid-cols-4 gap-1 text-center mb-2">
                  <div>
                    <p className="text-2xl font-bold">{timeLeft[event.id].days}</p>
                    <p className="text-xs text-muted-foreground">Days</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{timeLeft[event.id].hours}</p>
                    <p className="text-xs text-muted-foreground">Hours</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{timeLeft[event.id].minutes}</p>
                    <p className="text-xs text-muted-foreground">Minutes</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{timeLeft[event.id].seconds}</p>
                    <p className="text-xs text-muted-foreground">Seconds</p>
                  </div>
                </div>
                <Progress value={getProgressValue(event.id)} className="h-2" />
              </>
            ) : (
              <p className="text-center text-muted-foreground">Event has passed</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

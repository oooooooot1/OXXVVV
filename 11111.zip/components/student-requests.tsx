"use client"

import { useState, useEffect } from "react"
import { formatDistanceToNow } from "date-fns"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Clock, CheckCircle } from "lucide-react"

// Mock student requests
const initialRequests = [
  {
    id: 1,
    title: "Tuition Fee Payment",
    description: "Complete your tuition payment for the current semester",
    issueDate: new Date(2023, 7, 1),
    expiryDate: new Date(2023, 8, 15),
    status: "pending",
  },
  {
    id: 2,
    title: "ID Photo Submission",
    description: "Submit your photo for the university ID card",
    issueDate: new Date(2023, 7, 5),
    expiryDate: new Date(2023, 7, 20),
    status: "pending",
  },
  {
    id: 3,
    title: "Course Registration",
    description: "Register for your courses for the upcoming semester",
    issueDate: new Date(2023, 7, 10),
    expiryDate: new Date(2023, 8, 1),
    status: "pending",
  },
  {
    id: 4,
    title: "Assignment Submission",
    description: "Submit your final project for Computer Science",
    issueDate: new Date(2023, 7, 15),
    expiryDate: new Date(2023, 7, 30),
    status: "pending",
  },
]

export function StudentRequests() {
  const [requests, setRequests] = useState(initialRequests)

  // Check for expired requests every minute
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date()

      setRequests((prev) => prev.filter((request) => request.status === "pending" && request.expiryDate > now))
    }, 60 * 1000)

    return () => clearInterval(interval)
  }, [])

  const getTimeRemaining = (expiryDate: Date) => {
    return formatDistanceToNow(expiryDate, { addSuffix: true })
  }

  const getProgressValue = (issueDate: Date, expiryDate: Date) => {
    const now = new Date().getTime()
    const start = issueDate.getTime()
    const end = expiryDate.getTime()

    const totalDuration = end - start
    const elapsed = now - start

    return Math.min(100, Math.max(0, (elapsed / totalDuration) * 100))
  }

  const handleComplete = (id: number) => {
    setRequests((prev) => prev.map((request) => (request.id === id ? { ...request, status: "completed" } : request)))
  }

  return (
    <div className="space-y-4">
      <ScrollArea className="h-[300px] pr-4">
        <div className="space-y-4">
          {requests.length > 0 ? (
            requests.map((request) => (
              <div key={request.id} className="space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium flex items-center">
                      {request.title}
                      {request.status === "completed" && <CheckCircle className="ml-2 h-4 w-4 text-green-500" />}
                    </h4>
                    <p className="text-sm text-muted-foreground">{request.description}</p>
                  </div>
                  {request.status === "pending" && (
                    <Button variant="outline" size="sm" onClick={() => handleComplete(request.id)}>
                      Complete
                    </Button>
                  )}
                </div>

                {request.status === "pending" && (
                  <>
                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <span>Issued: {request.issueDate.toLocaleDateString()}</span>
                      <span className="flex items-center">
                        <Clock className="mr-1 h-3 w-3" />
                        Expires {getTimeRemaining(request.expiryDate)}
                      </span>
                    </div>
                    <Progress value={getProgressValue(request.issueDate, request.expiryDate)} className="h-1" />
                  </>
                )}
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <CheckCircle className="h-8 w-8 text-green-500 mb-2" />
              <h4 className="font-medium">All caught up!</h4>
              <p className="text-sm text-muted-foreground">You have no pending requests</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  )
}

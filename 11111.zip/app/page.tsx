import { LoginForm } from "@/components/login-form"

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight mb-2">University MW Global</h1>
          <p className="text-muted-foreground">Please sign in to continue</p>
          <p className="text-xs text-muted-foreground mt-1">© Osama Bashir</p>
        </div>
        <LoginForm />
      </div>
    </main>
  )
}

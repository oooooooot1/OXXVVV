"use client"

import { useState } from "react"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { User, Palette, Save } from "lucide-react"

export default function SettingsPage() {
  const { user } = useAuth()

  // Profile settings
  const [contactNumber, setContactNumber] = useState(user && "contactNumber" in user ? user.contactNumber : "")

  // Display settings
  const [darkMode, setDarkMode] = useState(false)
  const [animations, setAnimations] = useState(true)
  const [fontSize, setFontSize] = useState(100)

  const handleSaveProfile = () => {
    // In a real app, this would update the user's profile
    alert("Profile settings saved!")
  }

  const handleSaveDisplay = () => {
    // In a real app, this would update the display settings
    alert("Display settings saved!")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage your account settings and preferences</p>
      </div>

      <Tabs defaultValue="profile">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Profile Settings
          </TabsTrigger>
          <TabsTrigger value="display" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            Display Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Profile Settings</CardTitle>
              <CardDescription>Update your personal information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {user && "fullName" in user && (
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input id="fullName" value={user.fullName} disabled />
                  <p className="text-xs text-muted-foreground">Contact an administrator to change your name</p>
                </div>
              )}

              {user && "role" in user && user.role === "student" && "universityID" in user && (
                <div className="space-y-2">
                  <Label htmlFor="universityID">University ID</Label>
                  <Input id="universityID" value={user.universityID} disabled />
                  <p className="text-xs text-muted-foreground">Your university ID cannot be changed</p>
                </div>
              )}

              {user && "role" in user && user.role === "faculty" && "subject" in user && (
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Input id="subject" value={user.subject} disabled />
                  <p className="text-xs text-muted-foreground">Contact an administrator to change your subject</p>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="contactNumber">Contact Number</Label>
                <Input id="contactNumber" value={contactNumber} onChange={(e) => setContactNumber(e.target.value)} />
              </div>

              <Button onClick={handleSaveProfile} className="w-full">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="display" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Display Settings</CardTitle>
              <CardDescription>Customize your viewing experience</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="dark-mode">Dark Mode</Label>
                  <p className="text-sm text-muted-foreground">Switch between light and dark themes</p>
                </div>
                <Switch id="dark-mode" checked={darkMode} onCheckedChange={setDarkMode} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="animations">Animations</Label>
                  <p className="text-sm text-muted-foreground">Enable or disable UI animations</p>
                </div>
                <Switch id="animations" checked={animations} onCheckedChange={setAnimations} />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="font-size">Font Size ({fontSize}%)</Label>
                </div>
                <Slider
                  id="font-size"
                  min={75}
                  max={150}
                  step={5}
                  value={[fontSize]}
                  onValueChange={(value) => setFontSize(value[0])}
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Smaller</span>
                  <span>Default</span>
                  <span>Larger</span>
                </div>
              </div>

              <Button onClick={handleSaveDisplay} className="w-full">
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

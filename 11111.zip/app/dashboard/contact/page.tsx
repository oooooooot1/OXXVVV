export default function ContactPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Contact Us</h1>
        <p className="text-muted-foreground">Get in touch with the university</p>
      </div>

      <div className="grid gap-6">
        <div className="rounded-lg border bg-card text-card-foreground shadow-sm p-6">
          <h2 className="text-2xl font-bold mb-2">University MW Global</h2>
          <p className="text-xl mb-6">Excellence in Education</p>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">University President</h3>
              <p className="text-xl">Dr. Abdullah Al-Faisal</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Contact Number</h3>
              <p className="text-xl">+966 12 345 6789</p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Official Website</h3>
              <a
                href="https://www.university-mw-global.edu"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xl text-primary hover:underline"
              >
                www.university-mw-global.edu
              </a>
            </div>
          </div>

          <div className="mt-8 text-sm text-muted-foreground text-center">© Osama Bashir - All Rights Reserved</div>
        </div>
      </div>
    </div>
  )
}

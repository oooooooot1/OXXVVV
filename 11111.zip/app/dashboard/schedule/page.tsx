"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Clock, Calendar, Edit } from "lucide-react"

// Time slots
const timeSlots = ["08:00-09:30", "10:00-11:30", "12:00-13:30", "14:00-15:30", "16:00-17:30", "18:00-19:30"]

// Mock schedule data
const scheduleData = {
  A: [
    {
      day: "الأحد",
      slots: [
        { id: 1, time: "08:00-09:30", course: "Computer Science 101", instructor: "Dr. Omar Hassan" },
        { id: 2, time: "10:00-11:30", course: "Mathematics 202", instructor: "Dr. Aisha Mahmoud" },
        { id: 3, time: "12:00-13:30", course: "Physics 101", instructor: "Dr. Ahmed Ali" },
        null,
        null,
        null,
      ],
    },
    {
      day: "الإثنين",
      slots: [
        null,
        { id: 4, time: "10:00-11:30", course: "English Literature", instructor: "Dr. Layla Ibrahim" },
        { id: 5, time: "12:00-13:30", course: "History 101", instructor: "Dr. Mohammed Khalid" },
        { id: 6, time: "14:00-15:30", course: "Chemistry 201", instructor: "Dr. Fatima Zahra" },
        null,
        null,
      ],
    },
    {
      day: "الثلاثاء",
      slots: [
        { id: 7, time: "08:00-09:30", course: "Computer Science 101", instructor: "Dr. Omar Hassan" },
        { id: 8, time: "10:00-11:30", course: "Mathematics 202", instructor: "Dr. Aisha Mahmoud" },
        null,
        null,
        null,
        null,
      ],
    },
    {
      day: "الأربعاء",
      slots: [
        null,
        null,
        { id: 9, time: "12:00-13:30", course: "Physics 101", instructor: "Dr. Ahmed Ali" },
        { id: 10, time: "14:00-15:30", course: "English Literature", instructor: "Dr. Layla Ibrahim" },
        { id: 11, time: "16:00-17:30", course: "History 101", instructor: "Dr. Mohammed Khalid" },
        null,
      ],
    },
    {
      day: "الخميس",
      slots: [
        { id: 12, time: "08:00-09:30", course: "Chemistry 201", instructor: "Dr. Fatima Zahra" },
        null,
        null,
        null,
        null,
        null,
      ],
    },
    {
      day: "الجمعة",
      slots: [null, null, null, null, null, null],
    },
    {
      day: "السبت",
      slots: [null, null, null, null, null, null],
    },
  ],
  B: [
    {
      day: "الأحد",
      slots: [null, null, null, null, null, null],
    },
    {
      day: "الإثنين",
      slots: [
        null,
        { id: 1, time: "10:00-11:30", course: "Physics 101", instructor: "Dr. Ahmed Ali" },
        { id: 2, time: "12:00-13:30", course: "English Literature", instructor: "Dr. Layla Ibrahim" },
        { id: 3, time: "14:00-15:30", course: "History 101", instructor: "Dr. Mohammed Khalid" },
        null,
        null,
      ],
    },
    {
      day: "الثلاثاء",
      slots: [
        { id: 4, time: "08:00-09:30", course: "Computer Science 101", instructor: "Dr. Omar Hassan" },
        { id: 5, time: "10:00-11:30", course: "Mathematics 202", instructor: "Dr. Aisha Mahmoud" },
        null,
        null,
        null,
        null,
      ],
    },
    {
      day: "الأربعاء",
      slots: [
        null,
        { id: 6, time: "10:00-11:30", course: "Chemistry 201", instructor: "Dr. Fatima Zahra" },
        { id: 7, time: "12:00-13:30", course: "Physics 101", instructor: "Dr. Ahmed Ali" },
        { id: 8, time: "14:00-15:30", course: "English Literature", instructor: "Dr. Layla Ibrahim" },
        null,
        null,
      ],
    },
    {
      day: "الخميس",
      slots: [
        { id: 9, time: "08:00-09:30", course: "Computer Science 101", instructor: "Dr. Omar Hassan" },
        { id: 10, time: "10:00-11:30", course: "Mathematics 202", instructor: "Dr. Aisha Mahmoud" },
        null,
        null,
        null,
        null,
      ],
    },
    {
      day: "الجمعة",
      slots: [
        null,
        null,
        { id: 11, time: "12:00-13:30", course: "Chemistry 201", instructor: "Dr. Fatima Zahra" },
        null,
        null,
        null,
      ],
    },
    {
      day: "السبت",
      slots: [null, null, null, null, null, null],
    },
  ],
}

export default function SchedulePage() {
  const { user } = useAuth()
  const [group, setGroup] = useState<"A" | "B">("A")
  const [notes, setNotes] = useState("")
  const [nextLecture, setNextLecture] = useState<{
    course: string
    instructor: string
    time: string
    day: string
    timeLeft: string
  } | null>(null)
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [isAdmin, setIsAdmin] = useState(true)

  // حالة التعديل
  const [isEditing, setIsEditing] = useState(false)
  const [editingSlot, setEditingSlot] = useState<{
    groupIndex: "A" | "B"
    dayIndex: number
    slotIndex: number
    field: "course" | "instructor" | "time"
    value: string
  } | null>(null)

  // دالة تحديث الجدول
  const handleUpdateSchedule = (
    groupIndex: "A" | "B",
    dayIndex: number,
    slotIndex: number,
    field: "course" | "instructor" | "time",
    value: string,
  ) => {
    const newScheduleData = { ...scheduleData }

    // إذا كان الخلية فارغة، قم بإنشاء محاضرة جديدة
    if (!newScheduleData[groupIndex][dayIndex].slots[slotIndex]) {
      const newId = Math.floor(Math.random() * 1000) + 100
      newScheduleData[groupIndex][dayIndex].slots[slotIndex] = {
        id: newId,
        time: timeSlots[slotIndex],
        course: "",
        instructor: "",
      }
    }

    // تحديث الحقل المطلوب
    if (newScheduleData[groupIndex][dayIndex].slots[slotIndex]) {
      newScheduleData[groupIndex][dayIndex].slots[slotIndex][field] = value
    }

    // تحديث البيانات
    setLastUpdated(new Date())
  }

  // Set the group based on the user's group if they are a student
  useEffect(() => {
    if (user && "role" in user && user.role === "student" && "group" in user) {
      setGroup(user.group)
    }
  }, [user])

  // Calculate the next lecture
  useEffect(() => {
    const calculateNextLecture = () => {
      const now = new Date()
      const currentDay = now.getDay() // 0 = Sunday, 1 = Monday, etc.
      const currentHour = now.getHours()
      const currentMinute = now.getMinutes()

      // Convert current time to minutes since midnight
      const currentTimeInMinutes = currentHour * 60 + currentMinute

      // Map JavaScript day to our schedule days (1-7 where 1 is Monday)
      const dayMap = [6, 0, 1, 2, 3, 4, 5] // Sunday, Monday, Tuesday, etc.
      const mappedCurrentDay = dayMap[currentDay]

      // Check all days starting from today
      for (let dayOffset = 0; dayOffset < 7; dayOffset++) {
        const checkDay = (mappedCurrentDay + dayOffset) % 7
        const daySchedule = scheduleData[group][checkDay]

        // Skip if no schedule for this day
        if (!daySchedule) continue

        // Check all slots for this day
        for (let slotIndex = 0; slotIndex < daySchedule.slots.length; slotIndex++) {
          const slot = daySchedule.slots[slotIndex]

          // Skip empty slots
          if (!slot) continue

          // Parse slot time
          const [startTime, endTime] = slot.time.split("-")
          const [startHour, startMinute] = startTime.split(":").map(Number)
          const slotStartTimeInMinutes = startHour * 60 + startMinute

          // If we're checking today and the slot has already passed, skip it
          if (dayOffset === 0 && slotStartTimeInMinutes <= currentTimeInMinutes) {
            continue
          }

          // We found the next lecture
          const daysUntil = dayOffset
          const minutesUntil =
            dayOffset === 0
              ? slotStartTimeInMinutes - currentTimeInMinutes
              : 24 * 60 * dayOffset + slotStartTimeInMinutes - currentTimeInMinutes

          let timeLeftText = ""
          if (daysUntil === 0) {
            const hoursUntil = Math.floor(minutesUntil / 60)
            const minsUntil = minutesUntil % 60
            timeLeftText = `${hoursUntil}h ${minsUntil}m`
          } else {
            timeLeftText = `${daysUntil} day${daysUntil > 1 ? "s" : ""}, ${Math.floor((minutesUntil % (24 * 60)) / 60)}h ${minutesUntil % 60}m`
          }

          setNextLecture({
            course: slot.course,
            instructor: slot.instructor,
            time: slot.time,
            day: daySchedule.day,
            timeLeft: timeLeftText,
          })

          return
        }
      }

      // If we get here, no upcoming lectures were found
      setNextLecture(null)
    }

    calculateNextLecture()
    const interval = setInterval(calculateNextLecture, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [group])

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Class Schedule</h1>
        <p className="text-muted-foreground">View your weekly timetable</p>
      </div>

      {nextLecture && (
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Clock className="mr-2 h-5 w-5 text-primary" />
              المحاضرة القادمة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h3 className="font-bold text-lg">{nextLecture.course}</h3>
                <p className="text-sm text-muted-foreground">{nextLecture.instructor}</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <p className="font-medium">
                    {nextLecture.day}, {nextLecture.time}
                  </p>
                  <p className="text-sm text-primary font-medium">متبقي: {nextLecture.timeLeft}</p>
                </div>
                <div className="bg-primary text-primary-foreground w-12 h-12 rounded-full flex items-center justify-center animate-pulse">
                  <Clock className="h-6 w-6" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue={group} onValueChange={(value) => setGroup(value as "A" | "B")}>
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="A">Group A</TabsTrigger>
            <TabsTrigger value="B">Group B</TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            {isAdmin && (
              <Button
                variant={isEditing ? "default" : "outline"}
                size="sm"
                onClick={() => setIsEditing(!isEditing)}
                className="mr-2"
              >
                <Edit className="mr-1 h-3 w-3" />
                {isEditing ? "إنهاء التعديل" : "تعديل الجدول"}
              </Button>
            )}
            <Badge variant="outline" className="ml-auto">
              <Calendar className="mr-1 h-3 w-3" />
              آخر تحديث: {lastUpdated.toLocaleString()}
            </Badge>
          </div>
        </div>

        <TabsContent value="A" className="mt-4">
          <Card>
            <CardContent className="p-0 overflow-auto">
              <div className="min-w-[800px]">
                <table className="w-full border-collapse">
                  <thead>
                    <tr>
                      <th className="border p-2 bg-muted font-medium text-right w-24">اليوم</th>
                      {timeSlots.map((slot, index) => (
                        <th key={index} className="border p-2 bg-muted font-medium text-center">
                          {slot}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {scheduleData.A.map((day, dayIndex) => (
                      <tr key={dayIndex}>
                        <td className="border p-2 font-medium text-right">{day.day}</td>
                        {day.slots.map((slot, slotIndex) => (
                          <td key={slotIndex} className="border p-2 relative">
                            {slot ? (
                              <div className="space-y-1">
                                <div
                                  className="font-medium cursor-pointer hover:bg-gray-100 p-1 rounded"
                                  onClick={() => {
                                    if (isEditing) {
                                      setEditingSlot({
                                        groupIndex: "A",
                                        dayIndex,
                                        slotIndex,
                                        field: "course",
                                        value: slot.course,
                                      })
                                    }
                                  }}
                                >
                                  {editingSlot?.groupIndex === "A" &&
                                  editingSlot?.dayIndex === dayIndex &&
                                  editingSlot?.slotIndex === slotIndex &&
                                  editingSlot?.field === "course" ? (
                                    <input
                                      className="w-full p-1 border rounded"
                                      value={editingSlot.value}
                                      onChange={(e) => setEditingSlot({ ...editingSlot, value: e.target.value })}
                                      onBlur={() => {
                                        if (editingSlot.value !== slot.course) {
                                          handleUpdateSchedule("A", dayIndex, slotIndex, "course", editingSlot.value)
                                        }
                                        setEditingSlot(null)
                                      }}
                                      autoFocus
                                    />
                                  ) : (
                                    slot.course
                                  )}
                                </div>
                                <div
                                  className="text-xs text-muted-foreground cursor-pointer hover:bg-gray-100 p-1 rounded"
                                  onClick={() => {
                                    if (isEditing) {
                                      setEditingSlot({
                                        groupIndex: "A",
                                        dayIndex,
                                        slotIndex,
                                        field: "instructor",
                                        value: slot.instructor,
                                      })
                                    }
                                  }}
                                >
                                  {editingSlot?.groupIndex === "A" &&
                                  editingSlot?.dayIndex === dayIndex &&
                                  editingSlot?.slotIndex === slotIndex &&
                                  editingSlot?.field === "instructor" ? (
                                    <input
                                      className="w-full p-1 border rounded"
                                      value={editingSlot.value}
                                      onChange={(e) => setEditingSlot({ ...editingSlot, value: e.target.value })}
                                      onBlur={() => {
                                        if (editingSlot.value !== slot.instructor) {
                                          handleUpdateSchedule(
                                            "A",
                                            dayIndex,
                                            slotIndex,
                                            "instructor",
                                            editingSlot.value,
                                          )
                                        }
                                        setEditingSlot(null)
                                      }}
                                      autoFocus
                                    />
                                  ) : (
                                    slot.instructor
                                  )}
                                </div>
                                <div
                                  className="text-xs text-primary cursor-pointer hover:bg-gray-100 p-1 rounded"
                                  onClick={() => {
                                    if (isEditing) {
                                      setEditingSlot({
                                        groupIndex: "A",
                                        dayIndex,
                                        slotIndex,
                                        field: "time",
                                        value: slot.time,
                                      })
                                    }
                                  }}
                                >
                                  {editingSlot?.groupIndex === "A" &&
                                  editingSlot?.dayIndex === dayIndex &&
                                  editingSlot?.slotIndex === slotIndex &&
                                  editingSlot?.field === "time" ? (
                                    <input
                                      className="w-full p-1 border rounded"
                                      value={editingSlot.value}
                                      onChange={(e) => setEditingSlot({ ...editingSlot, value: e.target.value })}
                                      onBlur={() => {
                                        if (editingSlot.value !== slot.time) {
                                          handleUpdateSchedule("A", dayIndex, slotIndex, "time", editingSlot.value)
                                        }
                                        setEditingSlot(null)
                                      }}
                                      autoFocus
                                    />
                                  ) : (
                                    slot.time
                                  )}
                                </div>
                              </div>
                            ) : (
                              <div
                                className="h-20 flex items-center justify-center text-muted-foreground text-sm cursor-pointer"
                                onClick={() => {
                                  if (isEditing) {
                                    handleUpdateSchedule("A", dayIndex, slotIndex, "course", "محاضرة جديدة")
                                  }
                                }}
                              >
                                {isEditing && "+ إضافة محاضرة"}
                              </div>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="B" className="mt-4">
          <Card>
            <CardContent className="p-0 overflow-auto">
              <div className="min-w-[800px]">
                <table className="w-full border-collapse">
                  <thead>
                    <tr>
                      <th className="border p-2 bg-muted font-medium text-right w-24">اليوم</th>
                      {timeSlots.map((slot, index) => (
                        <th key={index} className="border p-2 bg-muted font-medium text-center">
                          {slot}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {scheduleData.B.map((day, dayIndex) => (
                      <tr key={dayIndex}>
                        <td className="border p-2 font-medium text-right">{day.day}</td>
                        {day.slots.map((slot, slotIndex) => (
                          <td key={slotIndex} className="border p-2 relative">
                            {slot ? (
                              <div className="space-y-1">
                                <div
                                  className="font-medium cursor-pointer hover:bg-gray-100 p-1 rounded"
                                  onClick={() => {
                                    if (isEditing) {
                                      setEditingSlot({
                                        groupIndex: "B",
                                        dayIndex,
                                        slotIndex,
                                        field: "course",
                                        value: slot.course,
                                      })
                                    }
                                  }}
                                >
                                  {editingSlot?.groupIndex === "B" &&
                                  editingSlot?.dayIndex === dayIndex &&
                                  editingSlot?.slotIndex === slotIndex &&
                                  editingSlot?.field === "course" ? (
                                    <input
                                      className="w-full p-1 border rounded"
                                      value={editingSlot.value}
                                      onChange={(e) => setEditingSlot({ ...editingSlot, value: e.target.value })}
                                      onBlur={() => {
                                        if (editingSlot.value !== slot.course) {
                                          handleUpdateSchedule("B", dayIndex, slotIndex, "course", editingSlot.value)
                                        }
                                        setEditingSlot(null)
                                      }}
                                      autoFocus
                                    />
                                  ) : (
                                    slot.course
                                  )}
                                </div>
                                <div
                                  className="text-xs text-muted-foreground cursor-pointer hover:bg-gray-100 p-1 rounded"
                                  onClick={() => {
                                    if (isEditing) {
                                      setEditingSlot({
                                        groupIndex: "B",
                                        dayIndex,
                                        slotIndex,
                                        field: "instructor",
                                        value: slot.instructor,
                                      })
                                    }
                                  }}
                                >
                                  {editingSlot?.groupIndex === "B" &&
                                  editingSlot?.dayIndex === dayIndex &&
                                  editingSlot?.slotIndex === slotIndex &&
                                  editingSlot?.field === "instructor" ? (
                                    <input
                                      className="w-full p-1 border rounded"
                                      value={editingSlot.value}
                                      onChange={(e) => setEditingSlot({ ...editingSlot, value: e.target.value })}
                                      onBlur={() => {
                                        if (editingSlot.value !== slot.instructor) {
                                          handleUpdateSchedule(
                                            "B",
                                            dayIndex,
                                            slotIndex,
                                            "instructor",
                                            editingSlot.value,
                                          )
                                        }
                                        setEditingSlot(null)
                                      }}
                                      autoFocus
                                    />
                                  ) : (
                                    slot.instructor
                                  )}
                                </div>
                                <div
                                  className="text-xs text-primary cursor-pointer hover:bg-gray-100 p-1 rounded"
                                  onClick={() => {
                                    if (isEditing) {
                                      setEditingSlot({
                                        groupIndex: "B",
                                        dayIndex,
                                        slotIndex,
                                        field: "time",
                                        value: slot.time,
                                      })
                                    }
                                  }}
                                >
                                  {editingSlot?.groupIndex === "B" &&
                                  editingSlot?.dayIndex === dayIndex &&
                                  editingSlot?.slotIndex === slotIndex &&
                                  editingSlot?.field === "time" ? (
                                    <input
                                      className="w-full p-1 border rounded"
                                      value={editingSlot.value}
                                      onChange={(e) => setEditingSlot({ ...editingSlot, value: e.target.value })}
                                      onBlur={() => {
                                        if (editingSlot.value !== slot.time) {
                                          handleUpdateSchedule("B", dayIndex, slotIndex, "time", editingSlot.value)
                                        }
                                        setEditingSlot(null)
                                      }}
                                      autoFocus
                                    />
                                  ) : (
                                    slot.time
                                  )}
                                </div>
                              </div>
                            ) : (
                              <div
                                className="h-20 flex items-center justify-center text-muted-foreground text-sm cursor-pointer"
                                onClick={() => {
                                  if (isEditing) {
                                    handleUpdateSchedule("B", dayIndex, slotIndex, "course", "محاضرة جديدة")
                                  }
                                }}
                              >
                                {isEditing && "+ إضافة محاضرة"}
                              </div>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center text-lg">
            <Edit className="mr-2 h-5 w-5" />
            Notes
          </CardTitle>
          <CardDescription>Add personal notes about your schedule</CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Add your notes here..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="min-h-[100px]"
          />
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-xs text-muted-foreground">Notes are saved automatically</p>
          <Button variant="outline" size="sm">
            Save
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

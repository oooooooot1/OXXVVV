"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import {
  Search,
  Users,
  UserCircle,
  Edit,
  Trash2,
  Upload,
  Download,
  Key,
  UserPlus,
  UserIcon as Male,
  UserIcon as Female,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/components/auth-provider"

// Mock people data
const students = [
  {
    id: 1,
    name: "Ahmed Mohammed",
    gender: "male",
    group: "A",
    department: "Computer Science",
    year: 3,
    universityID: "ST12345",
    secretCode: "1234@ABCD",
    isLeader: true,
  },
  {
    id: 2,
    name: "Fatima Ali",
    gender: "female",
    group: "B",
    department: "Medicine",
    year: 2,
    universityID: "ST67890",
    secretCode: "5678@EFGH",
    isLeader: false,
  },
  {
    id: 3,
    name: "Omar Hassan",
    gender: "male",
    group: "A",
    department: "Engineering",
    year: 4,
    universityID: "ST24680",
    secretCode: "2468@IJKL",
    isLeader: false,
  },
  {
    id: 4,
    name: "Layla Ibrahim",
    gender: "female",
    group: "B",
    department: "Business",
    year: 3,
    universityID: "ST13579",
    secretCode: "1357@MNOP",
    isLeader: false,
  },
  {
    id: 5,
    name: "Mohammed Khalid",
    gender: "male",
    group: "A",
    department: "Law",
    year: 2,
    universityID: "ST97531",
    secretCode: "9753@QRST",
    isLeader: false,
  },
  {
    id: 6,
    name: "Aisha Mahmoud",
    gender: "female",
    group: "B",
    department: "Computer Science",
    year: 1,
    universityID: "ST86420",
    secretCode: "8642@UVWX",
    isLeader: false,
  },
  {
    id: 7,
    name: "Yusuf Ahmed",
    gender: "male",
    group: "A",
    department: "Medicine",
    year: 4,
    universityID: "ST75319",
    secretCode: "7531@YZ12",
    isLeader: false,
  },
  {
    id: 8,
    name: "Nour Ali",
    gender: "female",
    group: "B",
    department: "Engineering",
    year: 2,
    universityID: "ST64208",
    secretCode: "6420@3456",
    isLeader: false,
  },
  {
    id: 9,
    name: "Khalid Omar",
    gender: "male",
    group: "A",
    department: "Business",
    year: 3,
    universityID: "ST53197",
    secretCode: "5319@7890",
    isLeader: false,
  },
  {
    id: 10,
    name: "Zainab Mohammed",
    gender: "female",
    group: "B",
    department: "Law",
    year: 1,
    universityID: "ST42086",
    secretCode: "4208@ABCD",
    isLeader: false,
  },
]

const faculty = [
  {
    id: 1,
    name: "Dr. Omar Hassan",
    gender: "male",
    department: "Computer Science",
    subject: "Programming",
    secretCode: "4321@DCBA",
  },
  {
    id: 2,
    name: "Dr. Aisha Mahmoud",
    gender: "female",
    department: "Mathematics",
    subject: "Calculus",
    secretCode: "8765@HGFE",
  },
  {
    id: 3,
    name: "Dr. Ahmed Ali",
    gender: "male",
    department: "Physics",
    subject: "Mechanics",
    secretCode: "2468@LKJI",
  },
  {
    id: 4,
    name: "Dr. Layla Ibrahim",
    gender: "female",
    department: "English",
    subject: "Literature",
    secretCode: "1357@PONM",
  },
  {
    id: 5,
    name: "Dr. Mohammed Khalid",
    gender: "male",
    department: "History",
    subject: "World History",
    secretCode: "9753@TSRQ",
  },
  {
    id: 6,
    name: "Dr. Fatima Zahra",
    gender: "female",
    department: "Chemistry",
    subject: "Organic Chemistry",
    secretCode: "8642@XWVU",
  },
]

export default function PeoplePage() {
  const { role } = useAuth()
  const [searchQuery, setSearchQuery] = useState("")
  const [studentsList, setStudentsList] = useState(students)
  const [facultyList, setFacultyList] = useState(faculty)
  const [editingStudent, setEditingStudent] = useState<any>(null)
  const [editingFaculty, setEditingFaculty] = useState<any>(null)
  const [editingCode, setEditingCode] = useState<any>(null)
  const isAdmin = role === "admin"

  const maleStudents = studentsList.filter((student) => student.gender === "male").length
  const femaleStudents = studentsList.filter((student) => student.gender === "female").length
  const maleFaculty = facultyList.filter((f) => f.gender === "male").length
  const femaleFaculty = facultyList.filter((f) => f.gender === "female").length

  const filteredStudents = studentsList
    .filter(
      (student) =>
        student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.universityID.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.secretCode.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    .sort((a, b) => a.name.localeCompare(b.name))

  const filteredFaculty = facultyList
    .filter(
      (f) =>
        f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.secretCode.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    .sort((a, b) => a.name.localeCompare(b.name))

  const handleDeleteAllStudents = () => {
    if (confirm("هل أنت متأكد من حذف جميع الطلاب؟")) {
      setStudentsList([])
    }
  }

  const handleDeleteAllFaculty = () => {
    if (confirm("هل أنت متأكد من حذف جميع أعضاء هيئة التدريس؟")) {
      setFacultyList([])
    }
  }

  const handleDeleteStudent = (id: number) => {
    setStudentsList(studentsList.filter((student) => student.id !== id))
  }

  const handleDeleteFaculty = (id: number) => {
    setFacultyList(facultyList.filter((faculty) => faculty.id !== id))
  }

  const handleUpdateCode = () => {
    if (editingCode) {
      if (editingCode.type === "student") {
        setStudentsList(
          studentsList.map((student) =>
            student.id === editingCode.id ? { ...student, secretCode: editingCode.secretCode } : student,
          ),
        )
      } else {
        setFacultyList(
          facultyList.map((faculty) =>
            faculty.id === editingCode.id ? { ...faculty, secretCode: editingCode.secretCode } : faculty,
          ),
        )
      }
      setEditingCode(null)
    }
  }

  // إضافة مرجع لعنصر إدخال الملف
  const fileInputRef = useRef<HTMLInputElement>(null)

  // إضافة متغير حالة للطالب الجديد
  const [newStudent, setNewStudent] = useState<any>({
    id: 0,
    name: "",
    gender: "male",
    group: "A",
    department: "",
    year: 1,
    universityID: "",
    secretCode: "",
    isLeader: false,
  })

  // دالة إضافة طالب جديد
  const handleAddStudent = () => {
    if (!newStudent.name || !newStudent.universityID || !newStudent.secretCode) {
      alert("الرجاء إدخال جميع البيانات المطلوبة")
      return
    }

    const newId = studentsList.length > 0 ? Math.max(...studentsList.map((s) => s.id)) + 1 : 1
    const studentToAdd = {
      ...newStudent,
      id: newId,
    }

    setStudentsList([...studentsList, studentToAdd])
    setNewStudent({
      id: 0,
      name: "",
      gender: "male",
      group: "A",
      department: "",
      year: 1,
      universityID: "",
      secretCode: "",
      isLeader: false,
    })

    alert("تمت إضافة الطالب بنجاح")
  }

  // تحديث دالة تعديل الطالب
  const handleUpdateStudent = () => {
    if (editingStudent) {
      setStudentsList(studentsList.map((student) => (student.id === editingStudent.id ? editingStudent : student)))
      setEditingStudent(null)
      alert("تم تحديث بيانات الطالب بنجاح")
    }
  }

  // دالة استيراد الطلاب من ملف نصي
  const handleImportStudents = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      const content = event.target?.result as string
      const lines = content.split("\n")

      const newStudents = []
      let currentId = Math.max(...studentsList.map((s) => s.id)) + 1

      for (let i = 0; i < lines.length; i += 3) {
        if (i + 2 < lines.length) {
          const name = lines[i].trim()
          const universityID = lines[i + 1].trim()
          const secretCode = lines[i + 2].trim()

          if (name && universityID && secretCode) {
            newStudents.push({
              id: currentId++,
              name,
              gender: name.includes("ة") || name.includes("ى") ? "female" : "male", // تخمين بسيط للجنس
              group: Math.random() > 0.5 ? "A" : "B", // تعيين عشوائي للمجموعة
              department: "قسم جديد",
              year: 1,
              universityID,
              secretCode,
              isLeader: false,
            })
          }
        }
      }

      if (newStudents.length > 0) {
        setStudentsList([...studentsList, ...newStudents])
        alert(`تم استيراد ${newStudents.length} طالب بنجاح`)
      } else {
        alert("لم يتم العثور على بيانات صالحة في الملف")
      }

      // إعادة تعيين حقل الملف
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }

    reader.readAsText(file)
  }

  // دالة تصدير الطلاب إلى ملف نصي
  const handleExportStudents = () => {
    let content = ""

    studentsList.forEach((student) => {
      content += `${student.name}\n${student.universityID}\n${student.secretCode}\n`
    })

    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)

    const a = document.createElement("a")
    a.href = url
    a.download = "students_export.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    alert("تم تصدير بيانات الطلاب بنجاح")
  }

  const handleImportFaculty = () => {
    // In a real app, this would open a file dialog and parse the file
    alert("سيتم فتح نافذة لاختيار ملف أعضاء هيئة التدريس")
  }

  const handleExportFaculty = () => {
    // In a real app, this would generate and download a file
    alert("سيتم تنزيل ملف بيانات أعضاء هيئة التدريس")
  }

  const handleUpdateFaculty = () => {
    if (editingFaculty) {
      setFacultyList(facultyList.map((faculty) => (faculty.id === editingFaculty.id ? editingFaculty : faculty)))
      setEditingFaculty(null)
      alert("تم تحديث بيانات عضو هيئة التدريس بنجاح")
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">دليل الأشخاص</h1>
        <p className="text-muted-foreground">تصفح الطلاب وأعضاء هيئة التدريس</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>إحصائيات الطلاب</CardTitle>
            <CardDescription>توزيع الطلاب حسب الجنس</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 bg-blue-50 dark:bg-blue-950 p-4 rounded-md">
                <Male className="h-8 w-8 text-blue-500" />
                <div>
                  <p className="font-bold text-2xl">{maleStudents}</p>
                  <p className="text-sm text-muted-foreground">طلاب</p>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-pink-50 dark:bg-pink-950 p-4 rounded-md">
                <Female className="h-8 w-8 text-pink-500" />
                <div>
                  <p className="font-bold text-2xl">{femaleStudents}</p>
                  <p className="text-sm text-muted-foreground">طالبات</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>إحصائيات هيئة التدريس</CardTitle>
            <CardDescription>توزيع أعضاء هيئة التدريس حسب الجنس</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 bg-blue-50 dark:bg-blue-950 p-4 rounded-md">
                <Male className="h-8 w-8 text-blue-500" />
                <div>
                  <p className="font-bold text-2xl">{maleFaculty}</p>
                  <p className="text-sm text-muted-foreground">أساتذة</p>
                </div>
              </div>
              <div className="flex items-center gap-2 bg-pink-50 dark:bg-pink-950 p-4 rounded-md">
                <Female className="h-8 w-8 text-pink-500" />
                <div>
                  <p className="font-bold text-2xl">{femaleFaculty}</p>
                  <p className="text-sm text-muted-foreground">أستاذات</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="البحث بالاسم، الرقم الجامعي، الكود، أو القسم..."
          className="pl-8"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue="students">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="students" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            الطلاب
          </TabsTrigger>
          <TabsTrigger value="faculty" className="flex items-center gap-2">
            <UserCircle className="h-4 w-4" />
            هيئة التدريس
          </TabsTrigger>
        </TabsList>

        <TabsContent value="students" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>قائمة الطلاب</CardTitle>
                <CardDescription>{filteredStudents.length} طالب</CardDescription>
              </div>
              {isAdmin && (
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <UserPlus className="h-4 w-4 mr-1" />
                        إضافة طالب
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>إضافة طالب جديد</DialogTitle>
                        <DialogDescription>أدخل بيانات الطالب الجديد</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="new-name" className="text-right">
                            الاسم
                          </Label>
                          <Input
                            id="new-name"
                            value={newStudent?.name || ""}
                            onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                            className="col-span-3"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="new-gender" className="text-right">
                            الجنس
                          </Label>
                          <div className="col-span-3 flex gap-4">
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="new-male"
                                name="new-gender"
                                value="male"
                                checked={newStudent?.gender === "male"}
                                onChange={() => setNewStudent({ ...newStudent, gender: "male" })}
                              />
                              <Label htmlFor="new-male">ذكر</Label>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="new-female"
                                name="new-gender"
                                value="female"
                                checked={newStudent?.gender === "female"}
                                onChange={() => setNewStudent({ ...newStudent, gender: "female" })}
                              />
                              <Label htmlFor="new-female">أنثى</Label>
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="new-universityID" className="text-right">
                            الرقم الجامعي
                          </Label>
                          <Input
                            id="new-universityID"
                            value={newStudent?.universityID || ""}
                            onChange={(e) => setNewStudent({ ...newStudent, universityID: e.target.value })}
                            className="col-span-3"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="new-group" className="text-right">
                            المجموعة
                          </Label>
                          <div className="col-span-3 flex gap-4">
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="new-groupA"
                                name="new-group"
                                value="A"
                                checked={newStudent?.group === "A"}
                                onChange={() => setNewStudent({ ...newStudent, group: "A" })}
                              />
                              <Label htmlFor="new-groupA">A</Label>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="new-groupB"
                                name="new-group"
                                value="B"
                                checked={newStudent?.group === "B"}
                                onChange={() => setNewStudent({ ...newStudent, group: "B" })}
                              />
                              <Label htmlFor="new-groupB">B</Label>
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="new-department" className="text-right">
                            القسم
                          </Label>
                          <Input
                            id="new-department"
                            value={newStudent?.department || ""}
                            onChange={(e) => setNewStudent({ ...newStudent, department: e.target.value })}
                            className="col-span-3"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="new-year" className="text-right">
                            السنة
                          </Label>
                          <Input
                            id="new-year"
                            type="number"
                            min="1"
                            max="6"
                            value={newStudent?.year || ""}
                            onChange={(e) => setNewStudent({ ...newStudent, year: Number.parseInt(e.target.value) })}
                            className="col-span-3"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="new-secretCode" className="text-right">
                            الكود السري
                          </Label>
                          <Input
                            id="new-secretCode"
                            value={newStudent?.secretCode || ""}
                            onChange={(e) => setNewStudent({ ...newStudent, secretCode: e.target.value })}
                            className="col-span-3"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="new-isLeader" className="text-right">
                            قائد الفصل
                          </Label>
                          <div className="col-span-3 flex items-center">
                            <input
                              type="checkbox"
                              id="new-isLeader"
                              checked={newStudent?.isLeader || false}
                              onChange={(e) => setNewStudent({ ...newStudent, isLeader: e.target.checked })}
                              className="mr-2"
                            />
                            <Label htmlFor="new-isLeader">تعيين كقائد فصل</Label>
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button onClick={handleAddStudent}>إضافة</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                  <input
                    type="file"
                    accept=".txt"
                    ref={fileInputRef}
                    onChange={handleImportStudents}
                    style={{ display: "none" }}
                  />
                  <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4 mr-1" />
                    استيراد
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleExportStudents}>
                    <Download className="h-4 w-4 mr-1" />
                    تصدير
                  </Button>
                  <Button variant="destructive" size="sm" onClick={handleDeleteAllStudents}>
                    <Trash2 className="h-4 w-4 mr-1" />
                    حذف الكل
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] pr-4">
                <div className="space-y-4">
                  {filteredStudents.map((student) => (
                    <div
                      key={student.id}
                      className="flex items-center justify-between gap-4 p-2 rounded-lg hover:bg-muted/50"
                    >
                      <div className="flex items-center gap-4">
                        <Avatar>
                          <AvatarFallback className={student.gender === "male" ? "bg-blue-100" : "bg-pink-100"}>
                            {student.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{student.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {student.universityID} • المجموعة {student.group} • {student.department} • السنة{" "}
                            {student.year}
                          </p>
                          <p className="text-xs text-muted-foreground">الكود: {student.secretCode}</p>
                        </div>
                      </div>

                      {isAdmin && (
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() =>
                                  setEditingCode({
                                    id: student.id,
                                    type: "student",
                                    secretCode: student.secretCode,
                                  })
                                }
                              >
                                <Key className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>تعديل كود الطالب</DialogTitle>
                                <DialogDescription>تعديل كود تسجيل الدخول للطالب {student.name}</DialogDescription>
                              </DialogHeader>
                              <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="secretCode" className="text-right">
                                    الكود
                                  </Label>
                                  <Input
                                    id="secretCode"
                                    value={editingCode?.secretCode || ""}
                                    onChange={(e) => setEditingCode({ ...editingCode, secretCode: e.target.value })}
                                    className="col-span-3"
                                  />
                                </div>
                              </div>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">إلغاء</Button>
                                </DialogClose>
                                <Button onClick={handleUpdateCode}>حفظ</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon" onClick={() => setEditingStudent({ ...student })}>
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>تعديل بيانات الطالب</DialogTitle>
                                <DialogDescription>تعديل معلومات الطالب {student.name}</DialogDescription>
                              </DialogHeader>
                              <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="name" className="text-right">
                                    الاسم
                                  </Label>
                                  <Input
                                    id="name"
                                    value={editingStudent?.name || ""}
                                    onChange={(e) => setEditingStudent({ ...editingStudent, name: e.target.value })}
                                    className="col-span-3"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="universityID" className="text-right">
                                    الرقم الجامعي
                                  </Label>
                                  <Input
                                    id="universityID"
                                    value={editingStudent?.universityID || ""}
                                    onChange={(e) =>
                                      setEditingStudent({ ...editingStudent, universityID: e.target.value })
                                    }
                                    className="col-span-3"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="isLeader" className="text-right">
                                    قائد الفصل
                                  </Label>
                                  <div className="col-span-3 flex items-center">
                                    <input
                                      type="checkbox"
                                      id="isLeader"
                                      checked={editingStudent?.isLeader || false}
                                      onChange={(e) =>
                                        setEditingStudent({ ...editingStudent, isLeader: e.target.checked })
                                      }
                                      className="mr-2"
                                    />
                                    <Label htmlFor="isLeader">تعيين كقائد فصل</Label>
                                  </div>
                                </div>
                              </div>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">إلغاء</Button>
                                </DialogClose>
                                <Button onClick={handleUpdateStudent}>حفظ</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Button variant="ghost" size="icon" onClick={() => handleDeleteStudent(student.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}

                  {filteredStudents.length === 0 && (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">لا يوجد طلاب مطابقين لبحثك.</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="faculty" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>قائمة أعضاء هيئة التدريس</CardTitle>
                <CardDescription>{filteredFaculty.length} عضو</CardDescription>
              </div>
              {isAdmin && (
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <UserPlus className="h-4 w-4 mr-1" />
                        إضافة عضو
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>إضافة عضو هيئة تدريس جديد</DialogTitle>
                        <DialogDescription>أدخل بيانات عضو هيئة التدريس الجديد</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        {/* Form fields would go here */}
                        <p className="text-center text-muted-foreground">نموذج إضافة عضو هيئة تدريس جديد</p>
                      </div>
                      <DialogFooter>
                        <Button>إضافة</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                  <Button variant="outline" size="sm" onClick={handleImportFaculty}>
                    <Upload className="h-4 w-4 mr-1" />
                    استيراد
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleExportFaculty}>
                    <Download className="h-4 w-4 mr-1" />
                    تصدير
                  </Button>
                  <Button variant="destructive" size="sm" onClick={handleDeleteAllFaculty}>
                    <Trash2 className="h-4 w-4 mr-1" />
                    حذف الكل
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] pr-4">
                <div className="space-y-4">
                  {filteredFaculty.map((member) => (
                    <div
                      key={member.id}
                      className="flex items-center justify-between gap-4 p-2 rounded-lg hover:bg-muted/50"
                    >
                      <div className="flex items-center gap-4">
                        <Avatar>
                          <AvatarFallback className={member.gender === "male" ? "bg-blue-100" : "bg-pink-100"}>
                            {member.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{member.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {member.department} • {member.subject}
                          </p>
                          <p className="text-xs text-muted-foreground">الكود: {member.secretCode}</p>
                        </div>
                      </div>

                      {isAdmin && (
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() =>
                                  setEditingCode({
                                    id: member.id,
                                    type: "faculty",
                                    secretCode: member.secretCode,
                                  })
                                }
                              >
                                <Key className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>تعديل كود عضو هيئة التدريس</DialogTitle>
                                <DialogDescription>تعديل كود تسجيل الدخول لـ {member.name}</DialogDescription>
                              </DialogHeader>
                              <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="secretCode" className="text-right">
                                    الكود
                                  </Label>
                                  <Input
                                    id="secretCode"
                                    value={editingCode?.secretCode || ""}
                                    onChange={(e) => setEditingCode({ ...editingCode, secretCode: e.target.value })}
                                    className="col-span-3"
                                  />
                                </div>
                              </div>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">إلغاء</Button>
                                </DialogClose>
                                <Button onClick={handleUpdateCode}>حفظ</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon" onClick={() => setEditingFaculty({ ...member })}>
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>تعديل بيانات عضو هيئة التدريس</DialogTitle>
                                <DialogDescription>تعديل معلومات {member.name}</DialogDescription>
                              </DialogHeader>
                              <div className="grid gap-4 py-4">
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="name" className="text-right">
                                    الاسم
                                  </Label>
                                  <Input
                                    id="name"
                                    value={editingFaculty?.name || ""}
                                    onChange={(e) => setEditingFaculty({ ...editingFaculty, name: e.target.value })}
                                    className="col-span-3"
                                  />
                                </div>
                                <div className="grid grid-cols-4 items-center gap-4">
                                  <Label htmlFor="subject" className="text-right">
                                    المادة
                                  </Label>
                                  <Input
                                    id="subject"
                                    value={editingFaculty?.subject || ""}
                                    onChange={(e) => setEditingFaculty({ ...editingFaculty, subject: e.target.value })}
                                    className="col-span-3"
                                  />
                                </div>
                              </div>
                              <DialogFooter>
                                <DialogClose asChild>
                                  <Button variant="outline">إلغاء</Button>
                                </DialogClose>
                                <Button onClick={handleUpdateFaculty}>حفظ</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>

                          <Button variant="ghost" size="icon" onClick={() => handleDeleteFaculty(member.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}

                  {filteredFaculty.length === 0 && (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground">لا يوجد أعضاء هيئة تدريس مطابقين لبحثك.</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

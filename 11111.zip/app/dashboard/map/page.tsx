"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ZoomIn, ZoomOut, Maximize, Minimize } from "lucide-react"

export default function MapPage() {
  const [zoom, setZoom] = useState(1)
  const [isFullscreen, setIsFullscreen] = useState(false)

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.1, 2))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.1, 0.5))
  }

  const handleFullscreen = () => {
    const element = document.documentElement

    if (!isFullscreen) {
      if (element.requestFullscreen) {
        element.requestFullscreen()
      }
      setIsFullscreen(true)
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      }
      setIsFullscreen(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Campus Map</h1>
        <p className="text-muted-foreground">Navigate the university campus</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>University MW Global Campus</CardTitle>
          <CardDescription>Interactive map of the main campus</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <div className="overflow-auto border rounded-md bg-muted/30" style={{ height: "70vh" }}>
              <div
                className="relative min-w-full min-h-full"
                style={{
                  transform: `scale(${zoom})`,
                  transformOrigin: "top left",
                  transition: "transform 0.2s ease-out",
                }}
              >
                {/* Placeholder for campus map image */}
                <div className="w-[1200px] h-[800px] bg-muted flex items-center justify-center">
                  <div className="text-center">
                    <h3 className="text-2xl font-bold mb-4">University MW Global Campus Map</h3>
                    <p className="text-muted-foreground mb-8">© Osama Bashir</p>
                    <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto">
                      <div className="border p-4 rounded-md bg-background">
                        <h4 className="font-medium">Main Building</h4>
                        <p className="text-sm text-muted-foreground">Administration & Classrooms</p>
                      </div>
                      <div className="border p-4 rounded-md bg-background">
                        <h4 className="font-medium">Library</h4>
                        <p className="text-sm text-muted-foreground">Study Areas & Resources</p>
                      </div>
                      <div className="border p-4 rounded-md bg-background">
                        <h4 className="font-medium">Science Complex</h4>
                        <p className="text-sm text-muted-foreground">Labs & Research Facilities</p>
                      </div>
                      <div className="border p-4 rounded-md bg-background">
                        <h4 className="font-medium">Student Center</h4>
                        <p className="text-sm text-muted-foreground">Activities & Dining</p>
                      </div>
                      <div className="border p-4 rounded-md bg-background">
                        <h4 className="font-medium">Sports Complex</h4>
                        <p className="text-sm text-muted-foreground">Gym & Athletic Fields</p>
                      </div>
                      <div className="border p-4 rounded-md bg-background">
                        <h4 className="font-medium">Dormitories</h4>
                        <p className="text-sm text-muted-foreground">Student Housing</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="absolute bottom-4 right-4 flex gap-2">
              <Button variant="secondary" size="icon" onClick={handleZoomIn}>
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button variant="secondary" size="icon" onClick={handleZoomOut}>
                <ZoomOut className="h-4 w-4" />
              </Button>
              <Button variant="secondary" size="icon" onClick={handleFullscreen}>
                {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

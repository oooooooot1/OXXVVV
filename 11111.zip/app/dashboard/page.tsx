"use client"

import { useEffect, useState } from "react"
import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Star, Clock, Bell, FileText, Calendar } from "lucide-react"
import { NewsFeed } from "@/components/news-feed"
import { CountdownWidget } from "@/components/countdown-widget"
import { ClassLeaders } from "@/components/class-leaders"
import { LibraryResources } from "@/components/library-resources"
import { StudentRequests } from "@/components/student-requests"
import { GradesDisplay } from "@/components/grades-display"

export default function DashboardPage() {
  const { user, role } = useAuth()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to University MW Global dashboard.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Bell className="mr-2 h-5 w-5 text-primary" />
              News Feed
            </CardTitle>
            <CardDescription>Latest university announcements</CardDescription>
          </CardHeader>
          <CardContent>
            <NewsFeed />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Clock className="mr-2 h-5 w-5 text-primary" />
              Upcoming Events
            </CardTitle>
            <CardDescription>Countdown to important dates</CardDescription>
          </CardHeader>
          <CardContent>
            <CountdownWidget />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Star className="mr-2 h-5 w-5 text-primary" />
              Class Leaders
            </CardTitle>
            <CardDescription>Student representatives</CardDescription>
          </CardHeader>
          <CardContent>
            <ClassLeaders />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <FileText className="mr-2 h-5 w-5 text-primary" />
              Library Resources
            </CardTitle>
            <CardDescription>Access study materials</CardDescription>
          </CardHeader>
          <CardContent>
            <LibraryResources />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Calendar className="mr-2 h-5 w-5 text-primary" />
              Student Requests
            </CardTitle>
            <CardDescription>Pending tasks and deadlines</CardDescription>
          </CardHeader>
          <CardContent>
            <StudentRequests />
          </CardContent>
        </Card>
      </div>

      {role === "student" && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-lg">
              <Star className="mr-2 h-5 w-5 text-primary" />
              My Grades
            </CardTitle>
            <CardDescription>Academic performance overview</CardDescription>
          </CardHeader>
          <CardContent>
            <GradesDisplay />
          </CardContent>
        </Card>
      )}
    </div>
  )
}

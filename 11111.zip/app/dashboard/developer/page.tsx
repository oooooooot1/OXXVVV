export default function DeveloperPage() {
  // Generate "hahahahaha..." text that fills the page
  const generateHahaText = () => {
    let text = ""
    for (let i = 0; i < 1000; i++) {
      text += "هههههههههه"
    }
    return text
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center">
      <div className="max-w-full overflow-hidden whitespace-normal break-words text-wrap">{generateHahaText()}</div>
    </div>
  )
}

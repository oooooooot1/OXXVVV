"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { FileText, ImageIcon, LinkIcon, FileArchiveIcon as FileZip, File, Clock } from "lucide-react"

// Mock courses data
const courses = [
  {
    id: 1,
    name: "Computer Science 101",
    instructor: "Dr. Omar Hassan",
    resourceCount: 12,
  },
  {
    id: 2,
    name: "Mathematics 202",
    instructor: "Dr. Aisha Mahmoud",
    resourceCount: 8,
  },
  {
    id: 3,
    name: "Physics 101",
    instructor: "Dr. Ahmed Ali",
    resourceCount: 15,
  },
  {
    id: 4,
    name: "English Literature",
    instructor: "Dr. Layla Ibrahim",
    resourceCount: 6,
  },
  {
    id: 5,
    name: "History 101",
    instructor: "Dr. Mohammed Khalid",
    resourceCount: 10,
  },
  {
    id: 6,
    name: "Chemistry 201",
    instructor: "Dr. Fatima Zahra",
    resourceCount: 14,
  },
]

// Mock resources for each course
const courseResources = {
  1: {
    channel: [
      { id: 1, title: "Course Announcements", date: "2023-08-01" },
      { id: 2, title: "Discussion Thread: Algorithms", date: "2023-07-25" },
    ],
    files: [
      { id: 1, title: "Syllabus", type: "pdf", size: "420 KB", date: "2023-08-01" },
      { id: 2, title: "Lecture Notes Week 1", type: "pdf", size: "1.2 MB", date: "2023-08-05" },
      { id: 3, title: "Programming Assignment 1", type: "pdf", size: "350 KB", date: "2023-08-10" },
    ],
    links: [
      { id: 1, title: "Online Compiler", url: "https://example.com/compiler", date: "2023-08-01" },
      { id: 2, title: "Tutorial Videos", url: "https://example.com/tutorials", date: "2023-08-05" },
    ],
    images: [
      { id: 1, title: "Class Diagram", type: "png", size: "1.5 MB", date: "2023-08-10" },
      { id: 2, title: "Algorithm Flowchart", type: "jpg", size: "800 KB", date: "2023-08-15" },
    ],
    text: [
      { id: 1, title: "Code Snippets", content: "// Example code snippets...", date: "2023-08-10" },
      { id: 2, title: "Study Tips", content: "1. Practice regularly...", date: "2023-08-15" },
    ],
    countdown: [
      { id: 1, title: "Assignment 1 Due", date: new Date(2023, 8, 15) },
      { id: 2, title: "Midterm Exam", date: new Date(2023, 9, 1) },
    ],
  },
}

export default function FilesPage() {
  const [selectedCourse, setSelectedCourse] = useState<number | null>(null)
  const [activeTab, setActiveTab] = useState("channel")

  const handleCourseClick = (courseId: number) => {
    setSelectedCourse(courseId)
    setActiveTab("channel")
  }

  const getResourceIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FileText className="h-4 w-4" />
      case "png":
      case "jpg":
        return <ImageIcon className="h-4 w-4" />
      case "zip":
        return <FileZip className="h-4 w-4" />
      default:
        return <File className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Course Files</h1>
        <p className="text-muted-foreground">Access course materials and resources</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {courses.map((course) => (
          <Dialog key={course.id}>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                className="h-auto py-4 px-6 flex flex-col items-start gap-2 text-left w-full"
                onClick={() => handleCourseClick(course.id)}
              >
                <h3 className="font-bold">{course.name}</h3>
                <p className="text-sm text-muted-foreground">{course.instructor}</p>
                <div className="flex items-center gap-1 text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">
                  <FileText className="h-3 w-3" />
                  {course.resourceCount} Resources
                </div>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>{course.name}</DialogTitle>
                <DialogDescription>Instructor: {course.instructor}</DialogDescription>
              </DialogHeader>

              {selectedCourse && courseResources[selectedCourse as keyof typeof courseResources] ? (
                <Tabs defaultValue="channel" value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid grid-cols-6 w-full">
                    <TabsTrigger value="channel">Channel</TabsTrigger>
                    <TabsTrigger value="files">Files</TabsTrigger>
                    <TabsTrigger value="links">Links</TabsTrigger>
                    <TabsTrigger value="images">Images</TabsTrigger>
                    <TabsTrigger value="text">Text</TabsTrigger>
                    <TabsTrigger value="countdown">Countdown</TabsTrigger>
                  </TabsList>

                  <ScrollArea className="h-[400px] mt-4 pr-4">
                    <TabsContent value="channel" className="space-y-4">
                      {courseResources[selectedCourse as keyof typeof courseResources].channel.map((item) => (
                        <Card key={item.id}>
                          <CardContent className="p-4">
                            <h4 className="font-medium">{item.title}</h4>
                            <p className="text-xs text-muted-foreground mt-1">Posted on {item.date}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </TabsContent>

                    <TabsContent value="files" className="space-y-4">
                      {courseResources[selectedCourse as keyof typeof courseResources].files.map((file) => (
                        <div key={file.id} className="flex items-start gap-3">
                          <div className="mt-0.5 bg-primary/10 p-2 rounded-md">{getResourceIcon(file.type)}</div>
                          <div className="flex-1">
                            <h4 className="font-medium">{file.title}</h4>
                            <div className="flex justify-between items-center mt-1">
                              <span className="text-xs text-muted-foreground">
                                {file.size} • {file.date}
                              </span>
                              <Button variant="ghost" size="sm" className="h-7">
                                Download
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </TabsContent>

                    <TabsContent value="links" className="space-y-4">
                      {courseResources[selectedCourse as keyof typeof courseResources].links.map((link) => (
                        <div key={link.id} className="flex items-start gap-3">
                          <div className="mt-0.5 bg-primary/10 p-2 rounded-md">
                            <LinkIcon className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">{link.title}</h4>
                            <p className="text-sm text-primary truncate">{link.url}</p>
                            <div className="flex justify-between items-center mt-1">
                              <span className="text-xs text-muted-foreground">{link.date}</span>
                              <Button variant="ghost" size="sm" className="h-7">
                                Visit
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </TabsContent>

                    <TabsContent value="images" className="space-y-4">
                      {courseResources[selectedCourse as keyof typeof courseResources].images.map((image) => (
                        <div key={image.id} className="flex items-start gap-3">
                          <div className="mt-0.5 bg-primary/10 p-2 rounded-md">
                            <ImageIcon className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">{image.title}</h4>
                            <div className="flex justify-between items-center mt-1">
                              <span className="text-xs text-muted-foreground">
                                {image.size} • {image.date}
                              </span>
                              <Button variant="ghost" size="sm" className="h-7">
                                View
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </TabsContent>

                    <TabsContent value="text" className="space-y-4">
                      {courseResources[selectedCourse as keyof typeof courseResources].text.map((text) => (
                        <Card key={text.id}>
                          <CardContent className="p-4">
                            <h4 className="font-medium">{text.title}</h4>
                            <p className="text-sm mt-2 whitespace-pre-line">{text.content}</p>
                            <p className="text-xs text-muted-foreground mt-2">Posted on {text.date}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </TabsContent>

                    <TabsContent value="countdown" className="space-y-4">
                      {courseResources[selectedCourse as keyof typeof courseResources].countdown.map((event) => (
                        <Card key={event.id}>
                          <CardContent className="p-4">
                            <div className="flex items-center gap-2 mb-2">
                              <Clock className="h-4 w-4 text-primary" />
                              <h4 className="font-medium">{event.title}</h4>
                            </div>
                            <p className="text-sm">Due on {event.date.toLocaleDateString()}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {Math.ceil((event.date.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days
                              remaining
                            </p>
                          </CardContent>
                        </Card>
                      ))}
                    </TabsContent>
                  </ScrollArea>
                </Tabs>
              ) : (
                <div className="py-8 text-center">
                  <p className="text-muted-foreground">No resources available for this course yet.</p>
                </div>
              )}
            </DialogContent>
          </Dialog>
        ))}
      </div>
    </div>
  )
}
